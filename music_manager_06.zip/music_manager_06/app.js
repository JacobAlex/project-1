var express = require('express');
var path = require('path');
var logger = require('morgan');
var cookieParser = require('cookie-parser');
var bodyParser = require('body-parser');
var session = require('express-session');
var expressValidator = require('express-validator');
var flash = require('connect-flash');
var firebase = require('./config');

var fbRef = firebase.config();

//var fRef = firebaseAPP();

//var firebase = require('firebase');
/*
var config = {
  apiKey: "AIzaSyCXIqPDXKrTYrZOkzzT5VMXVwJkc4H_kfs",
  authDomain: "musicmanager-dba63.firebaseapp.com",
  databaseURL: "https://musicmanager-dba63.firebaseio.com",
  storageBucket: "gs://musicmanager-dba63.appspot.com",
};
firebase.initializeApp(config);
*/

// Route Files
var controllers = require('./controllers/index');
var albums = require('./controllers/albums');
var genres = require('./controllers/genres');
var users = require('./controllers/users');

// Init App
var app = express();

// View Engine
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

// Logger
app.use(logger('dev'));

// Body Parser
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(cookieParser());

// Handle Sessions
app.use(session({
  secret:'secret',
  saveUninitialized: true,
  resave: true
}));

// Validator
app.use(expressValidator({
  errorFormatter: function(param, msg, value) {
      var namespace = param.split('.')
      , root    = namespace.shift()
      , formParam = root;

    while(namespace.length) {
      formParam += '[' + namespace.shift() + ']';
    }
    return {
      param : formParam,
      msg   : msg,
      value : value
    };
  }
}));

// Static Folder
app.use(express.static(path.join(__dirname, 'public')));

// Connect Flash
app.use(flash());

// Global Vars
app.use(function (req, res, next) {
  res.locals.success_msg = req.flash('success_msg');
  res.locals.error_msg = req.flash('error_msg');
  res.locals.error = req.flash('error');
  //res.locals.authdata = firebase.auth();
  //res.locals.page = req.url;
  //res.locals.user = snapshot.val();
  next();
});

/*
// Get User Info
app.get('*', function(req, res, next){
  if(firebase.auth() != null){
    var userRef = new Firebase('https://musicmanager-dba63.firebaseio.com/users/');
    userRef.orderByChild("uid").startAt(firebase.auth().uid).endAt(firebase.auth().uid).on("child_added", function(snapshot) {
      res.locals.user = snapshot.val();
    });
  }
  next();
});
*/
/*
app.get('*', function(req, res, next){
  if(fbRef.getAuth() != null){
    var userRef = new Firebase('https://musicmanager-dba63.firebaseio.com/users/');
    userRef.orderByChild("uid").startAt(fbRef.getAuth().uid).endAt(fbRef.getAuth().uid).on("child_added", function(snapshot) {
      res.locals.user = snapshot.val();
    });
  }
  next();
});
*/

/*
app.get('*', function(req, res, next){
  var user = firebase.auth().currentUser;
  var first_name, last_name;
  if(user != null){
    //res.locals.user = snapshot.val();
    first_name = user.first_name;
    last_name = user.last_name;

    user.orderByChild("uid").startAt(firebase.auth().uid).endAt(firebase.auth().uid).on("child_added", function(snapshot) {
      res.locals.user = snapshot.val();
    });
  }
});
*/

// Controllers
app.use('/', controllers);
app.use('/albums', albums);
app.use('/genres', genres);
app.use('/users', users);

/*
// Set Port
app.set('port', (process.env.PORT || 3000));

// Run Server
app.listen(app.get('port'), function(){
  console.log('Server started on port: '+app.get('port'));
});
*/