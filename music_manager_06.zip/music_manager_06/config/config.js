var firebase = require('firebase');

var config = function(){
    var config = {
            apiKey: "AIzaSyCXIqPDXKrTYrZOkzzT5VMXVwJkc4H_kfs",
            authDomain: "musicmanager-dba63.firebaseapp.com",
            databaseURL: "https://musicmanager-dba63.firebaseio.com",
            storageBucket: "gs://musicmanager-dba63.appspot.com",
        };
        firebase.initializeApp(config);
}

module.exports = config;

/*
var config = {
  apiKey: "AIzaSyCXIqPDXKrTYrZOkzzT5VMXVwJkc4H_kfs",
  authDomain: "musicmanager-dba63.firebaseapp.com",
  databaseURL: "https://musicmanager-dba63.firebaseio.com",
  storageBucket: "gs://musicmanager-dba63.appspot.com",
};
firebase.initializeApp(config);
*/
