var config = require('./config');

module.exports = {
    config: config
}